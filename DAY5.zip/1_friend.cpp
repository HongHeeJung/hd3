// 1_friend.cpp - 75 page
class Bike
{
	int gear;
public:
};

void fixBike()
{
	Bike b;
	b.gear = 10;
}

int main()
{
	fixBike();
}