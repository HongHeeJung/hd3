#include <iostream>
#include <string>
#include <vector>

int main()
{
	std::string s1 = "AAA";
	std::string s2 = "BBB";

	std::string s3 = s1 + s2; // s1.operator+(s2)

	std::vector<int> v = { 1,2,3 };

	int n = v[0];  
}