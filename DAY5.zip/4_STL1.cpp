// 3_STL1 - 213 page
#include <iostream>
#include <vector>
#include <list>

int main()
{
	// �迭 vs vector
	int x[5] = { 1,2,3,4,5 };

	std::vector<int> v = { 1,2,3,4,5 };
}





