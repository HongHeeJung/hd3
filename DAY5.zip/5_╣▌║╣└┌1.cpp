// 4_�ݺ���1 - 220 page
#include <iostream>
#include <vector>
#include <list>

int main()
{
	int x[5] = { 1,2,3,4,5 };


	std::list<int> s = { 1,2,3,4,5 };
}



